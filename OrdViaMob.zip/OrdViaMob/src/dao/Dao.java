package dao;
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Model;
import util.DBConnection;
 
public class Dao {
 
 public String registerUser(Model registermodel)
 {
 String fname = registermodel.getFname();
 String lname = registermodel.getLname();
 String email = registermodel.getEmail();
 String pno = registermodel.getPno();
 String dob = registermodel.getDob();
 String address = registermodel.getAddress();
 String state = registermodel.getState();
 String city = registermodel.getCity();
 String password = registermodel.getPassword();
 
 Connection con = null;
 PreparedStatement preparedStatement = null;
 
 try
 {
 con = DBConnection.createConnection();
 String query = "insert into register(Fname,Lname,Email,Pno,Dob,Address,State,City,Password) values (?,?,?,?,?,?,?,?,?)"; //Insert user details into the table 'USERS'
 preparedStatement = con.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
 preparedStatement.setString(1, fname);
 preparedStatement.setString(2, lname);
 preparedStatement.setString(3, email);
 preparedStatement.setString(4, pno);
 preparedStatement.setString(5, dob);
 preparedStatement.setString(6, address);
 preparedStatement.setString(7, state);
 preparedStatement.setString(8, city);
 preparedStatement.setString(9, password);
 
 int i= preparedStatement.executeUpdate();
 
 if (i!=0)
 {//Just to ensure data has been inserted into the database
	 return "SUCCESS"; 
 }
 else
 {
	 return "not inserted";
 }
 }
 catch(SQLException e)
 {
 e.printStackTrace();
 }
 
 return "Oops.. Something went wrong there..!";  // On failure, send a message from here.
 }
}