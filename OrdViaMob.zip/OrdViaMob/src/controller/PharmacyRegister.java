package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.PRegisterDao;
import model.Model;

/**
 * Servlet implementation class PharmacyRegister
 */
@WebServlet("/PharmacyRegister")
public class PharmacyRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PharmacyRegister() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String name = request.getParameter("name");
		 String address = request.getParameter("address");
		 String state = request.getParameter("state");
		 String city = request.getParameter("city");
		 String email = request.getParameter("email");
		 String pno = request.getParameter("pno");
		 String hour = request.getParameter("hour");
		
		 String password = request.getParameter("password");
		 
		 Model registermodel = new Model();
		 //Using Java Beans - An easiest way to play with group of related data
		 registermodel.setName(name);
		 
		 registermodel.setEmail(email);
		 registermodel.setAddress(address);
		 registermodel.setState(state);
		 registermodel.setCity(city);
		 registermodel.setPno(pno);
		 registermodel.setHour(hour);
		
		 registermodel.setPassword(password); 
		 
		 PRegisterDao registerDao = new PRegisterDao();
		 
		 //The core Logic of the Registration application is present here. We are going to insert user data in to the database.
		 String userRegistered = registerDao.registerUser(registermodel);
		 
		 if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
		 {
		 request.getRequestDispatcher("/Plogin.jsp").forward(request, response);
		 }
		 else   //On Failure, display a meaningful message to the User.
		 {
		 request.setAttribute("errMessage", userRegistered);
		 request.getRequestDispatcher("/PRegister.jsp").forward(request, response);
		 }
	}

}
